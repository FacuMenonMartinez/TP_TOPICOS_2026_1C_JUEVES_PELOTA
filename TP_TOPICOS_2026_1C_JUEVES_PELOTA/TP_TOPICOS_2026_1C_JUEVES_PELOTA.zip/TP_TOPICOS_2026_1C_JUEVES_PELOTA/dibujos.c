#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#include "dibujos.h"
#include "GBT/gbt.h"
#include "piezas.h"
#include "movimiento.h"
#include "caracteres.h"

    uint16_t grilla_Origen_X;
    uint16_t grilla_Origen_Y;

void calcular_Posicion(uint16_t grilla_X,uint16_t grilla_Y, uint16_t  *coord_X, uint16_t  *coord_Y){
    grilla_Origen_X =  (VENTANA_ANCHO/2)-((GRILLA_COL * (MINO_LADO + (MINO_BORDE *2)))/2);
    grilla_Origen_Y  =  20;
    //Calcular coordenada X
    *coord_X = grilla_Origen_X + (grilla_X * (MINO_LADO + MINO_BORDE));
    //Calcular coordenada Y
    *coord_Y = grilla_Origen_Y + (grilla_Y * (MINO_LADO + MINO_BORDE));
}

void dibujar_mino(uint16_t coord_X, uint16_t coord_Y, uint8_t color_Centro, uint8_t color_Borde){

    uint8_t color;
    uint16_t oX = 0 ,oY = 0;
    //Calcular posicion en pixeles de donde se va a dibujar
    calcular_Posicion(coord_X, coord_Y, &oX, &oY);

    for(uint16_t y = 0; y < MINO_LADO; y++){
        for(uint16_t x = 0; x < MINO_LADO; x++){
            color = pieza_Mino[y][x]? color_Borde : color_Centro;
             gbt_dibujar_pixel(oX+x,oY+y,color);
        }
    }
}

void dibujar_fondo(uint16_t coord_X, uint16_t coord_Y, uint8_t color_Centro){

    uint16_t oX = 1 ,oY = 1;
    //Calcular posicion en pixeles de donde se va a dibujar
    calcular_Posicion(coord_X, coord_Y, &oX, &oY);

    for(uint16_t y = 0; y < FONDO_LADO; y++){
        for(uint16_t x = 0; x < FONDO_LADO; x++){
             gbt_dibujar_pixel(oX+x+1,oY+y+1,color_Centro);
        }
    }
}

void dibujar_Pieza(e_Piezas pieza, pieza_Pos *posicion, uint8_t color_Centro,uint8_t color_Borde){
    for(uint16_t i = 0; i<PIEZA_LADO; i++){
        for(uint16_t j = 0; j<PIEZA_LADO; j++){
            if (piezas[pieza][posicion->Rot][j][i] == true){
                dibujar_mino(posicion->X+i, posicion->Y+j, color_Centro,color_Borde);
            }
        }
    }
}

//Dibujar pieza fuera de la grilla de juego, recibe coordendas en pixeles
void dibujar_Pieza_Aux(e_Piezas pieza, e_Piezas_Rotacion posicion, uint16_t coord_X, uint16_t coord_Y){
        for(uint16_t i = 0; i<PIEZA_LADO; i++){
            for(uint16_t j = 0; j<PIEZA_LADO; j++){
                if (piezas[pieza][posicion][j][i] == true){
                //dibujar mino
                    for(uint16_t y = 0; y < MINO_LADO; y++){
                        for(uint16_t x = 0; x < MINO_LADO; x++){
                            uint8_t color = pieza_Mino[y][x]? 8 : 9;
                            gbt_dibujar_pixel(coord_X + i*(MINO_LADO + MINO_BORDE) + x,coord_Y + j*(MINO_LADO + MINO_BORDE) + y,color);
                        }
                    }
                }
            }
        }
}

void dibujar_Pieza_Siguiente(e_Piezas pieza){
    //Dibujar pieza siguiente
    //dibujar_Pieza_Aux(pieza, e_Pieza_0, grilla_Origen_X + (MINO_LADO+MINO_BORDE)*(GRILLA_COL+5), grilla_Origen_Y+50);
    dibujar_Pieza_Aux(pieza, e_Pieza_0, grilla_Origen_X+ (MINO_LADO+MINO_BORDE)*(GRILLA_COL+8), grilla_Origen_Y+10);
    //Dibujar texto para pieza siguiente
    uint8_t str_Pieza_Sig[15]= {c_P,c_I,c_E,c_Z,c_A,c_ES,c_S,c_I,c_G,c_U,c_I,c_E,c_N,c_T, c_E};
    dibujar_Palabra_F2(str_Pieza_Sig,15,grilla_Origen_X+ (MINO_LADO+MINO_BORDE)*(GRILLA_COL+1) ,grilla_Origen_Y ,1,9);
}

void dibujar_Grilla_Juego(){
    for(uint8_t y = 0; y<GRILLA_FIL; y++){
        for(uint8_t x = 0; x<GRILLA_COL; x++){
            if(grilla_Juego[y][x]){
                //que hago con los colores?
                dibujar_mino(x, y, 8, 9);
            }
             else{
                dibujar_fondo(x,y,5);
            }
        }
    }
}

int verificar_Filas(){
    uint64_t cont;
    for(uint8_t y = 0; y<GRILLA_FIL; y++){
        cont = 0;
        for(uint8_t x = 0; x<GRILLA_COL; x++){
            if(grilla_Juego[y][x]){
                cont++;
            }

        }
        if (cont == GRILLA_COL){
            return y; //Fila a eliminar
        }
    }
    return -1;
}

void eliminar_Fila(int fila_Eliminar){
    for(int y = fila_Eliminar; y > 0; y--){
        for(uint8_t x = 0; x < GRILLA_COL; x++){
            grilla_Juego[y][x] = grilla_Juego[y-1][x];
        }
    }
    // limpiar la fila superior
    for(uint8_t x = 0; x < GRILLA_COL; x++){
        grilla_Juego[0][x] = 0;
    }
}

void grilla_Limpiar(){
    for(int y = 0; y > GRILLA_FIL; y++){
        for(int x = 0; x<GRILLA_COL; x++){
            grilla_Juego[y][x] = 0;
        }
    }
    dibujar_Grilla_Juego();
}

//Funcion que dibuja los caracteres en forma de palabra
void dibujar_Palabra_F1(uint8_t palabra[], uint8_t tam, uint16_t pos_X, uint16_t pos_Y, uint8_t escala, uint8_t luz, uint8_t sombra, uint8_t base){
            for(uint8_t i=0; i<tam; i++){
                dibujar_Caracter_F1(palabra[i], pos_X + i*12*escala ,+ pos_Y,escala,sombra, luz, base);
            }
}

void dibujar_Palabra_F2(uint8_t palabra[], uint8_t tam, uint16_t pos_X, uint16_t pos_Y, uint8_t escala, uint8_t color){
            for(uint8_t i=0; i<tam; i++){
                dibujar_Caracter_F2(palabra[i], pos_X + i*7*escala ,+ pos_Y,escala,color);
            }
}

