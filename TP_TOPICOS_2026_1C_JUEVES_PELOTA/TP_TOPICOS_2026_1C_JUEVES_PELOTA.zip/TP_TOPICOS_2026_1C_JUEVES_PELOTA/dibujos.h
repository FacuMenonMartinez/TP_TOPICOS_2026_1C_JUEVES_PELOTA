#ifndef DIBUJOS_H_INCLUDED
#define DIBUJOS_H_INCLUDED

#include "piezas.h"

 extern uint16_t grilla_Origen_X;
 extern uint16_t grilla_Origen_Y;

/*
Esta funcion recibe un nro entero que corresponde a un indice
dentro de una matriz de 10x20 que representa la grilla del juego
y devuelve la coordenada de esa grilla para pasarlas a la funcion
que dibuja la pieza

*/

void calcular_Posicion(uint16_t grilla_X,uint16_t grilla_Y, uint16_t  *coord_X, uint16_t  *coord_Y);

//Funcion para dibujar mino
void dibujar_mino(uint16_t coord_X, uint16_t coord_Y, uint8_t color_Centro, uint8_t color_Borde);

void dibujar_fondo(uint16_t coord_X, uint16_t coord_Y, uint8_t color_Centro);

//Funcion para dibujar pieza
void dibujar_Pieza(e_Piezas pieza, pieza_Pos *posicion, uint8_t color_Centro,uint8_t color_Borde);

//Dibujar la grilla con las piezas que se encuentran fijas
void dibujar_Grilla_Juego();

/** \brief
 *  Verifica que fila esta completada
 * \return -1 si no hay filas completas, sino devuelve el nro de fila completa
 */
int verificar_Filas();

void eliminar_Fila(int fila_Eliminar);

//Limpiar grilla de juego
void grilla_Limpiar();

//Dibujar pieza fuera de la grilla de juego, recibe coordendas en pixeles
void dibujar_Pieza_Aux(e_Piezas pieza, e_Piezas_Rotacion posicion, uint16_t coord_X, uint16_t coord_Y);

//Dibujar pieza siguiente y texto
void dibujar_Pieza_Siguiente(e_Piezas pieza);


//Funcion para dibujar texto
    //Usa la fuente 1
    //Recibe un vector que contiene los caracteres de la palabra y cantidad de elementos del mismo,
    // coordenada en X, en Y, escala del caracter, color luz, sombra y base.
void dibujar_Palabra_F1 (uint8_t [], uint8_t , uint16_t , uint16_t , uint8_t , uint8_t , uint8_t , uint8_t );
void dibujar_Palabra_F2(uint8_t[], uint8_t, uint16_t, uint16_t, uint8_t, uint8_t);


#endif // DIBUJOS_H_INCLUDED
